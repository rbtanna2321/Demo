
const Restaurant = require('../models/user.model.js');
const async = require("async");
// Save FormData - User to MongoDB
exports.save = (req, res) => {
	console.log('Post a User: ' + JSON.stringify(req.body));
    // Create a Customer
  var array =[];
  for(var i =0 ; i < req.body.dishes.length; i++ ){
    var item = req.body.dishes[i];
    array.push(item)
  }
    const restaurant = new Restaurant({
      meal: req.body.meal,
      dishes: array,
      restaurant: req.body.restaurant,
      numOfMember: req.body.person
    });
    // Save a Customer in the MongoDB
  restaurant.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};

exports.findAll = (req, res) =>  {
  console.log("Fetch all Restaurant");
  Restaurant.find()
    .then(users => {
      res.send(users);
    }).catch(err => {
    res.status(500).send({
      message: err.message
    });
  });
};
exports.download = (req, res) =>  {
  console.log("Download all Restaurant Data");
  Restaurant.find({isDeleted:false})
    .then(users => {
      var BookingRecords = users;
      var workbook = new Excel.Workbook();
      workbook.creator = 'Me';
      var sheetName = 'Data';
      var sheet = workbook.addWorksheet(sheetName);
      sheet.state = 'visible';
      sheet.columns = [
        {header: 'Restaurant', key: 'restaurant'},
        {header: 'Meal', key: 'meal'},
        {header: 'Number of People', key: 'numofPeople'},
        {header: 'Company', key: 'company'},
        {header: 'Date of Creation', key: 'createdAt'}
      ];
      async.each(BookingRecords, function (row, cb) {
        sheet.addRow({
          restaurant: row.restaurant,
          meal: row.meal,
          numOfPeople: row.numOfPeople,
          createdAt: _MOMENT(row.createdAt).format("DD-MM-YYYY")
        });
        commit();
        cb();
      }, function (err, result) {
        workbook.xlsx.writeBuffer().then(function (data) {
          var returnObj = {buffer: data};
          console.log("Success: ", returnObj);
        });
      });
    }).catch(err => {
    res.status(500).send({
      message: err.message
    });
  });
};

