module.exports = function(app) {

	var express = require("express");
	var router = express.Router();
	const restaurants = require('../controllers/user.controller.js');

	var path = __basedir + '/views';
	app.set('views', __dirname + '/views');
	app.use(express.static(__dirname + '/views'));
	app.use('/css',express.static(__dirname +'css'));

	app.get('/', (req,res) => {
		res.sendFile(path + "/index.html")
	})

    // Save a User to MongoDB
    app.post('/api/restaurants/save', restaurants.save);
    // Retrieve all Users
    app.get('/api/users/all', restaurants.findAll);

	  app.get('/api/booking/Download', restaurants.download);


	app.use("/",router);
 
	app.use("*", (req,res) => {
		res.sendFile(path + "/404.html");
	});


}

