const mongoose = require('mongoose');
 
const BookingSchema = mongoose.Schema({
  meal: String,
  dishes: [{
    dishName:  String,
    numberofDish: String
  }],
  restaurant: String,
  numOfMember: String,
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
 
module.exports = mongoose.model('Restaurant', BookingSchema);